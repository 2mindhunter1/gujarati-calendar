package com.example.gujaraticalendar

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

class MainActivity : AppCompatActivity() {

    private lateinit var tvGujMonthHeader: TextView
    private lateinit var tvVikramSamvat: TextView
    private lateinit var tvEngMonthSub: TextView
    private lateinit var recyclerCalendar: RecyclerView
    private lateinit var btnSyncOnline: ImageButton

    private lateinit var tvSelectedGujDate: TextView
    private lateinit var tvSelectedTithiTime: TextView
    private lateinit var tvSelectedEngDate: TextView
    private lateinit var tvSelectedNakshatra: TextView
    private lateinit var tvSelectedSunTimes: TextView
    private lateinit var tvSelectedFestival: TextView
    private lateinit var tvLiveChoghadiya: TextView
    private lateinit var layoutMonthFestivals: LinearLayout

    private lateinit var adapter: CalendarAdapter

    private var currentMonth: YearMonth = YearMonth.now()
    private var selectedDate: LocalDate = LocalDate.now()
    private var remoteHolidays: Map<String, String> = emptyMap()
    private var isSyncing: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootLayout: View = findViewById(R.id.rootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        tvGujMonthHeader = findViewById(R.id.tvGujMonthHeader)
        tvVikramSamvat = findViewById(R.id.tvVikramSamvat)
        tvEngMonthSub = findViewById(R.id.tvEngMonthSub)
        recyclerCalendar = findViewById(R.id.recyclerCalendar)
        btnSyncOnline = findViewById(R.id.btnSyncOnline)

        tvSelectedGujDate = findViewById(R.id.tvSelectedGujDate)
        tvSelectedTithiTime = findViewById(R.id.tvSelectedTithiTime)
        tvSelectedEngDate = findViewById(R.id.tvSelectedEngDate)
        tvSelectedNakshatra = findViewById(R.id.tvSelectedNakshatra)
        tvSelectedSunTimes = findViewById(R.id.tvSelectedSunTimes)
        tvSelectedFestival = findViewById(R.id.tvSelectedFestival)
        tvLiveChoghadiya = findViewById(R.id.tvLiveChoghadiya)
        layoutMonthFestivals = findViewById(R.id.layoutMonthFestivals)

        val btnPrevMonth: MaterialButton = findViewById(R.id.btnPrevMonth)
        val btnNextMonth: MaterialButton = findViewById(R.id.btnNextMonth)
        val btnToday: MaterialButton = findViewById(R.id.btnToday)
        val btnViewChoghadiya: MaterialButton = findViewById(R.id.btnViewChoghadiya)

        recyclerCalendar.layoutManager = GridLayoutManager(this, 7)
        adapter = CalendarAdapter(emptyList(), selectedDate) { clickedDate ->
            selectedDate = clickedDate
            renderMonth()
        }
        recyclerCalendar.adapter = adapter

        btnPrevMonth.setOnClickListener {
            currentMonth = currentMonth.minusMonths(1)
            selectedDate = currentMonth.atDay(1)
            renderMonth()
        }

        btnNextMonth.setOnClickListener {
            currentMonth = currentMonth.plusMonths(1)
            selectedDate = currentMonth.atDay(1)
            renderMonth()
        }

        btnToday.setOnClickListener {
            selectedDate = LocalDate.now()
            currentMonth = YearMonth.from(selectedDate)
            renderMonth()
        }

        btnSyncOnline.setOnClickListener {
            performOnlineSync(isManual = true)
        }

        btnViewChoghadiya.setOnClickListener {
            val panchang = PanchangEngine.getPanchangForDate(selectedDate, remoteHolidays)
            showChoghadiyaBottomSheet(panchang)
        }

        remoteHolidays = HolidaySyncManager.getCachedHolidays(this)
        renderMonth()

        // Automatic real-time check on app start
        performOnlineSync(isManual = false)
    }

    private fun performOnlineSync(isManual: Boolean) {
        if (isSyncing) return
        isSyncing = true

        // Spin icon smoothly in upper right corner
        btnSyncOnline.animate().rotationBy(360f).setDuration(700L).start()

        if (isManual) {
            Toast.makeText(this, "રીઅલ-ટાઈમ અપડેટ ચેક થઈ રહ્યું છે...", Toast.LENGTH_SHORT).show()
        }

        lifecycleScope.launch {
            val result = HolidaySyncManager.syncFromGitHub(this@MainActivity)
            isSyncing = false

            if (result.success) {
                val changed = result.holidays != remoteHolidays
                remoteHolidays = result.holidays
                renderMonth()
                if (isManual || changed) {
                    Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                }
            } else if (isManual) {
                Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun renderMonth() {
        val firstDay = currentMonth.atDay(1)
        val daysInMonth = currentMonth.lengthOfMonth()
        val startOffset = firstDay.dayOfWeek.value % 7

        val cells = mutableListOf<CalendarCell>()
        repeat(startOffset) {
            cells.add(CalendarCell(null, null))
        }

        val monthPanchangs = mutableListOf<PanchangDay>()
        for (day in 1..daysInMonth) {
            val date = currentMonth.atDay(day)
            val p = PanchangEngine.getPanchangForDate(date, remoteHolidays)
            cells.add(CalendarCell(date, p))
            monthPanchangs.add(p)
        }

        val distinctGujMonths = monthPanchangs.map { it.gujaratiMonthName }.distinct()
        tvGujMonthHeader.text = distinctGujMonths.joinToString(" - ")

        val distinctSamvat = monthPanchangs.map { it.vikramSamvat }.distinct()
        val samvatText = distinctSamvat.joinToString(" / ") { PanchangEngine.toGujaratiDigits(it) }
        tvVikramSamvat.text = "વિક્રમ સંવત $samvatText"

        val engMonthName = PanchangEngine.ENGLISH_MONTHS_GUJ[currentMonth.monthValue - 1]
        tvEngMonthSub.text = "$engMonthName ${currentMonth.year}"

        adapter.updateData(cells, selectedDate)

        val selectedPanchang = PanchangEngine.getPanchangForDate(selectedDate, remoteHolidays)
        updateSelectedDayCard(selectedPanchang)
        updateMonthFestivalsList(monthPanchangs)
    }

    private fun updateSelectedDayCard(p: PanchangDay) {
        val weekday = PanchangEngine.getGujaratiWeekday(p.date.dayOfWeek)
        tvSelectedGujDate.text = "${p.gujaratiMonthName} ${p.pakshaName} ${p.tithiName} ($weekday)"

        val extraNote = if (p.tithiSpecialNote != null) "  •  ${p.tithiSpecialNote}" else ""
        tvSelectedTithiTime.text = "તિથિ સમાપ્તિ: ${p.tithiEndNote}$extraNote"

        val engMonth = PanchangEngine.ENGLISH_MONTHS_GUJ[p.date.monthValue - 1]
        tvSelectedEngDate.text = "અંગ્રેજી તારીખ: ${p.date.dayOfMonth} $engMonth ${p.date.year}"

        tvSelectedNakshatra.text = "નક્ષત્ર: ${p.nakshatraName}"
        tvSelectedSunTimes.text = "સૂર્યોદય: ${p.sunriseTime}  •  સૂર્યાસ્ત: ${p.sunsetTime}"

        if (p.festival != null) {
            tvSelectedFestival.visibility = View.VISIBLE
            tvSelectedFestival.text = "વિશેષ દિવસ / તહેવાર: ${p.festival}"
        } else {
            tvSelectedFestival.visibility = View.GONE
        }

        val (daySlots, nightSlots) = PanchangEngine.getChoghadiyaForDay(p)
        val currentSlot = (daySlots + nightSlots).firstOrNull { it.isCurrent }
        if (currentSlot != null) {
            tvLiveChoghadiya.visibility = View.VISIBLE
            tvLiveChoghadiya.text = "અત્યારે ચાલુ ચોઘડિયું: ${currentSlot.name} (${currentSlot.nature}) • ${currentSlot.timeRange}"
        } else {
            tvLiveChoghadiya.visibility = View.GONE
        }
    }

    private fun updateMonthFestivalsList(monthPanchangs: List<PanchangDay>) {
        layoutMonthFestivals.removeAllViews()
        val festivals = monthPanchangs.filter { it.festival != null }

        if (festivals.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "આ મહિનામાં કોઈ વિશેષ તહેવાર નથી."
                textSize = 14f
                setTextColor(Color.parseColor("#5D4037"))
            }
            layoutMonthFestivals.addView(emptyTv)
            return
        }

        for (item in festivals) {
            val row = LayoutInflater.from(this)
                .inflate(R.layout.item_festival_row, layoutMonthFestivals, false)
            val tvFestDate: TextView = row.findViewById(R.id.tvFestDate)
            val tvFestName: TextView = row.findViewById(R.id.tvFestName)
            val tvFestTithi: TextView = row.findViewById(R.id.tvFestTithi)

            val wd = PanchangEngine.getGujaratiWeekday(item.date.dayOfWeek)
            tvFestDate.text = "${item.date.dayOfMonth}/${item.date.monthValue}"
            tvFestName.text = item.festival
            tvFestTithi.text = "${item.gujaratiMonthName} ${item.pakshaName} ${item.tithiName} ($wd)"

            row.setOnClickListener {
                selectedDate = item.date
                renderMonth()
            }
            layoutMonthFestivals.addView(row)
        }
    }

    private fun showChoghadiyaBottomSheet(panchang: PanchangDay) {
        val dialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_choghadiya, null)

        val tvSheetTitle: TextView = view.findViewById(R.id.tvSheetTitle)
        val containerDay: LinearLayout = view.findViewById(R.id.containerDayChoghadiya)
        val containerNight: LinearLayout = view.findViewById(R.id.containerNightChoghadiya)

        val wd = PanchangEngine.getGujaratiWeekday(panchang.date.dayOfWeek)
        tvSheetTitle.text = "${panchang.date.dayOfMonth}/${panchang.date.monthValue}/${panchang.date.year} ($wd) - ચોઘડિયા"

        val (daySlots, nightSlots) = PanchangEngine.getChoghadiyaForDay(panchang)

        fun addSlots(slots: List<ChoghadiyaSlot>, container: LinearLayout) {
            for (slot in slots) {
                val row = LayoutInflater.from(this)
                    .inflate(R.layout.item_choghadiya_row, container, false)
                val tvName: TextView = row.findViewById(R.id.tvChoghadiyaName)
                val tvNature: TextView = row.findViewById(R.id.tvChoghadiyaNature)
                val tvTime: TextView = row.findViewById(R.id.tvChoghadiyaTime)

                tvName.text = if (slot.isCurrent) "${slot.name} (અત્યારે ચાલુ)" else slot.name
                tvNature.text = slot.nature
                tvTime.text = slot.timeRange

                val color = when (slot.quality) {
                    ChoghadiyaQuality.SHUBH -> Color.parseColor("#2E7D32")
                    ChoghadiyaQuality.NEUTRAL -> Color.parseColor("#EF6C00")
                    ChoghadiyaQuality.ASHUBH -> Color.parseColor("#C62828")
                }
                tvName.setTextColor(color)
                tvNature.setTextColor(color)

                if (slot.isCurrent) {
                    row.setBackgroundColor(Color.parseColor("#E8F5E9"))
                }
                container.addView(row)
            }
        }

        addSlots(daySlots, containerDay)
        addSlots(nightSlots, containerNight)

        dialog.setContentView(view)
        dialog.show()
    }
}
