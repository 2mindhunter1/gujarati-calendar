package com.example.gujaraticalendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

object PanchangEngine {

    val GUJARATI_MONTHS = listOf(
        "ચૈત્ર", "વૈશાખ", "જેઠ", "અષાઢ",
        "શ્રાવણ", "ભાદરવો", "આસો", "કારતક",
        "માગશર", "પોષ", "મહા", "ફાગણ"
    )

    val ENGLISH_MONTHS_GUJ = listOf(
        "જાન્યુઆરી (January)", "ફેબ્રુઆરી (February)", "માર્ચ (March)",
        "એપ્રિલ (April)", "મે (May)", "જૂન (June)",
        "જુલાઈ (July)", "ઓગસ્ટ (August)", "સપ્ટેમ્બર (September)",
        "ઓક્ટોબર (October)", "નવેમ્બર (November)", "ડિસેમ્બર (December)"
    )

    private val TITHI_NAMES_1_TO_15 = listOf(
        "એકમ", "બીજ", "ત્રીજ", "ચોથ", "પાંચમ",
        "છઠ્ઠ", "સાતમ", "આઠમ", "નોમ", "દશમ",
        "અગિયારસ", "બારસ", "તેરસ", "ચૌદશ", "પૂનમ"
    )

    private val NAKSHATRAS = listOf(
        "અશ્વિની", "ભરણી", "કૃત્તિકા", "રોહિણી", "મૃગશીર્ષ", "આર્દ્રા",
        "પુનર્વસુ", "પુષ્ય", "આશ્લેષા", "મઘા", "પૂર્વા ફાલ્ગુની", "ઉત્તરા ફાલ્ગુની",
        "હસ્ત", "ચિત્રા", "સ્વાતિ", "વિશાખા", "અનુરાધા", "જ્યેષ્ઠા",
        "મૂળ", "પૂર્વાષાઢા", "ઉત્તરાષાઢા", "શ્રવણ", "ધનિષ્ઠા", "શતભિષા",
        "પૂર્વા ભાદ્રપદ", "ઉત્તરા ભાદ્રપદ", "રેવતી"
    )

    fun toGujaratiDigits(input: String): String {
        val gujDigits = charArrayOf('૦', '૧', '૨', '૩', '૪', '૫', '૬', '૭', '૮', '૯')
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(gujDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toGujaratiDigits(number: Int): String = toGujaratiDigits(number.toString())

    fun getGujaratiWeekday(dayOfWeek: DayOfWeek): String {
        return when (dayOfWeek) {
            DayOfWeek.SUNDAY -> "રવિવાર"
            DayOfWeek.MONDAY -> "સોમવાર"
            DayOfWeek.TUESDAY -> "મંગળવાર"
            DayOfWeek.WEDNESDAY -> "બુધવાર"
            DayOfWeek.THURSDAY -> "ગુરુવાર"
            DayOfWeek.FRIDAY -> "શુક્રવાર"
            DayOfWeek.SATURDAY -> "શનિવાર"
        }
    }

    private fun norm360(deg: Double): Double {
        val r = deg % 360.0
        return if (r < 0) r + 360.0 else r
    }

    private fun julianDay(year: Int, month: Int, day: Int, istHour: Double): Double {
        val utHour = istHour - 5.5
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = y / 100
        val b = 2 - a + (a / 4)
        return floor(365.25 * (y + 4716)) +
            floor(30.6001 * (m + 1)) +
            day + utHour / 24.0 + b - 1524.5
    }

    private fun sunLongitude(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val l0 = norm360(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = Math.toRadians(norm360(357.52911 + 35999.05029 * t - 0.0001537 * t * t))
        val c = ((1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(m) +
            (0.019993 - 0.000101 * t) * sin(2 * m) +
            0.000289 * sin(3 * m))
        val trueLong = l0 + c
        val omega = Math.toRadians(125.04 - 1934.136 * t)
        return norm360(trueLong - 0.00569 - 0.00478 * sin(omega))
    }

    private fun moonLongitude(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val lp = norm360(218.3164477 + 481267.88123421 * t - 0.0015786 * t * t + (t * t * t) / 538841.0)
        val d = Math.toRadians(norm360(297.8501921 + 445267.1114034 * t - 0.0018819 * t * t))
        val m = Math.toRadians(norm360(357.5291092 + 35999.0502909 * t - 0.0001536 * t * t))
        val mp = Math.toRadians(norm360(134.9633964 + 477198.8675055 * t + 0.0087414 * t * t))
        val f = Math.toRadians(norm360(93.2720950 + 483202.0175233 * t - 0.0036539 * t * t))

        val sigmaL = (
            6288774.0 * sin(mp) +
                1274027.0 * sin(2 * d - mp) +
                658314.0 * sin(2 * d) +
                213618.0 * sin(2 * mp) -
                185116.0 * sin(m) -
                114332.0 * sin(2 * f) +
                58793.0 * sin(2 * d - 2 * mp) +
                57066.0 * sin(2 * d - m - mp) +
                53322.0 * sin(2 * d + mp) +
                45758.0 * sin(2 * d - m) -
                40923.0 * sin(m - mp) -
                34720.0 * sin(d) -
                30383.0 * sin(m + mp) +
                15327.0 * sin(2 * d - 2 * f)
            )
        return norm360(lp + sigmaL / 1000000.0)
    }

    private fun lahiriAyanamsa(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        return 23.853056 + 1.396971 * t
    }

    private fun getTithiAtJd(jd: Double): Int {
        val diff = norm360(moonLongitude(jd) - sunLongitude(jd))
        return floor(diff / 12.0).toInt() + 1 // 1..30
    }

    private fun findAmavasyaJd(jdApprox: Double, direction: Int): Double {
        var jd = jdApprox
        repeat(45) {
            val diff = norm360(moonLongitude(jd) - sunLongitude(jd))
            val signed = if (diff > 180.0) diff - 360.0 else diff
            if (direction < 0 && signed > 10.0) {
                jd -= 1.0
                return@repeat
            }
            if (direction > 0 && signed < -10.0) {
                jd += 1.0
                return@repeat
            }
            if (abs(signed) < 0.05) return jd
            jd -= signed / 12.190749
        }
        return jd
    }

    private fun findTithiEndIstHours(date: LocalDate, sunriseIstHour: Double, tithiIndex: Int): Double {
        val targetDeg = (tithiIndex * 12.0) % 360.0
        var jd = julianDay(date.year, date.monthValue, date.dayOfMonth, sunriseIstHour)
        repeat(15) {
            val diff = norm360(moonLongitude(jd) - sunLongitude(jd))
            var rem = (targetDeg - diff) % 360.0
            if (rem < 0) rem += 360.0
            if (rem > 180.0) rem -= 360.0
            if (abs(rem) < 0.001) return@repeat
            jd += (rem / 12.190749)
        }
        val jdMidnight = julianDay(date.year, date.monthValue, date.dayOfMonth, 0.0)
        return (jd - jdMidnight) * 24.0
    }

    // Sunrise & Sunset in minutes from midnight for Gujarat (Ahmedabad: 23.0225 N, 72.5714 E, IST +5.5)
    private fun calculateSunMinutes(date: LocalDate, isSunrise: Boolean): Int {
        val lat = 23.0225
        val lon = 72.5714
        val tz = 5.5
        val n = date.dayOfYear
        val lngHour = lon / 15.0
        val zenith = 90.833

        val t = n + (if (isSunrise) (6.0 - lngHour) / 24.0 else (18.0 - lngHour) / 24.0)
        val m = (0.9856 * t) - 3.289
        val l = norm360(m + (1.916 * sin(Math.toRadians(m))) + (0.020 * sin(Math.toRadians(2 * m))) + 282.634)
        var ra = norm360(Math.toDegrees(atan(0.91764 * tan(Math.toRadians(l)))))
        val lQuad = floor(l / 90.0) * 90.0
        val raQuad = floor(ra / 90.0) * 90.0
        ra = (ra + (lQuad - raQuad)) / 15.0

        val sinDec = 0.39782 * sin(Math.toRadians(l))
        val cosDec = cos(asin(sinDec))
        val cosH = (cos(Math.toRadians(zenith)) - (sinDec * sin(Math.toRadians(lat)))) /
            (cosDec * cos(Math.toRadians(lat)))

        val clampedCosH = cosH.coerceIn(-1.0, 1.0)
        val hDeg = if (isSunrise) 360.0 - Math.toDegrees(acos(clampedCosH)) else Math.toDegrees(acos(clampedCosH))
        val h = hDeg / 15.0

        val localMeanT = h + ra - (0.06571 * t) - 6.622
        val ut = (localMeanT - lngHour) % 24.0
        var localT = (ut + tz) % 24.0
        if (localT < 0) localT += 24.0

        return (localT * 60.0).roundToInt()
    }

    fun formatMinutesShort(totalMinutes: Int): String {
        val mins = ((totalMinutes % 1440) + 1440) % 1440
        val h24 = mins / 60
        val m = mins % 60
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        return toGujaratiDigits(String.format("%02d:%02d", h12, m))
    }

    private fun formatTithiEndNote(endIstHours: Double): String {
        val totalRoundedMinutes = (endIstHours * 60.0).roundToInt()
        val isNextDay = totalRoundedMinutes >= 1440
        val dayMins = totalRoundedMinutes % 1440
        val h24 = dayMins / 60
        val m = dayMins % 60

        val nextDayPrefix = if (isNextDay && h24 > 0) "બીજા દિવસે " else ""
        val period = when {
            h24 == 0 -> "મધ્યરાત્રિએ"
            h24 < 6 -> "વહેલી સવારે"
            h24 < 12 -> "સવારે"
            h24 < 17 -> "બપોરે"
            h24 < 20 -> "સાંજે"
            else -> "રાત્રે"
        }
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        val timeStr = toGujaratiDigits(String.format("%02d:%02d", h12, m))
        return "$nextDayPrefix$period $timeStr સુધી"
    }

    private fun getTithiLabelOnly(tithiIndex: Int): String {
        val isSud = tithiIndex <= 15
        val paksha = if (isSud) "સુદ" else "વદ"
        val inPaksha = if (isSud) tithiIndex else tithiIndex - 15
        val name = if (tithiIndex == 30) "અમાસ" else TITHI_NAMES_1_TO_15[inPaksha - 1]
        return "$paksha $name"
    }

    fun getPanchangForDate(date: LocalDate, remoteHolidays: Map<String, String>): PanchangDay {
        val srMin = calculateSunMinutes(date, isSunrise = true)
        val ssMin = calculateSunMinutes(date, isSunrise = false)
        val nextDate = date.plusDays(1)
        val prevDate = date.minusDays(1)
        val nextSrRaw = calculateSunMinutes(nextDate, isSunrise = true)
        val prevSrRaw = calculateSunMinutes(prevDate, isSunrise = true)
        val nextSrMin = nextSrRaw + 1440

        val jdTodaySr = julianDay(date.year, date.monthValue, date.dayOfMonth, srMin / 60.0)
        val jdPrevSr = julianDay(prevDate.year, prevDate.monthValue, prevDate.dayOfMonth, prevSrRaw / 60.0)
        val jdNextSr = julianDay(nextDate.year, nextDate.monthValue, nextDate.dayOfMonth, nextSrRaw / 60.0)

        val sunLon = sunLongitude(jdTodaySr)
        val moonLon = moonLongitude(jdTodaySr)
        val ayanamsa = lahiriAyanamsa(jdTodaySr)

        val tithiIndex = getTithiAtJd(jdTodaySr)
        val prevTithiIndex = getTithiAtJd(jdPrevSr)
        val nextTithiIndex = getTithiAtJd(jdNextSr)

        val expectedNextTithi = (tithiIndex % 30) + 1
        val kshayaTithiIndex = if (nextTithiIndex != expectedNextTithi) expectedNextTithi else null
        val isVridhiTithi = (tithiIndex == prevTithiIndex)

        val specialNote = when {
            kshayaTithiIndex != null -> "ક્ષય તિથિ: ${getTithiLabelOnly(kshayaTithiIndex)}"
            isVridhiTithi -> "વૃદ્ધિ તિથિ"
            else -> null
        }

        val endIstHours = findTithiEndIstHours(date, srMin / 60.0, tithiIndex)
        val tithiEndNote = formatTithiEndNote(endIstHours)

        val prevAma = findAmavasyaJd(jdTodaySr - (tithiIndex - 1) * 0.98, -1)
        val nextAma = findAmavasyaJd(jdTodaySr + (30 - tithiIndex) * 0.98, +1)

        val rashiStart = floor(norm360(sunLongitude(prevAma) - lahiriAyanamsa(prevAma)) / 30.0).toInt()
        val rashiEnd = floor(norm360(sunLongitude(nextAma) - lahiriAyanamsa(nextAma)) / 30.0).toInt()
        val isAdhik = (rashiStart == rashiEnd)
        val monthIndex = rashiEnd // 0=Chaitra .. 7=Kartak .. 11=Fagan

        val vikramSamvat = if (monthIndex >= 7 && date.monthValue >= 9) {
            date.year + 57
        } else {
            date.year + 56
        }

        val isSud = tithiIndex <= 15
        val pakshaName = if (isSud) "સુદ" else "વદ"
        val tithiInPaksha = if (isSud) tithiIndex else tithiIndex - 15
        val tithiName = if (tithiIndex == 30) "અમાસ" else TITHI_NAMES_1_TO_15[tithiInPaksha - 1]

        val siderealMoon = norm360(moonLon - ayanamsa)
        val nakshatraIdx = floor(siderealMoon / (360.0 / 27.0)).toInt().coerceIn(0, 26)
        val nakshatraName = NAKSHATRAS[nakshatraIdx]

        val specialType = when {
            tithiIndex == 15 -> SpecialTithiType.POONAM
            tithiIndex == 30 -> SpecialTithiType.AMAS
            tithiIndex == 11 || tithiIndex == 26 || kshayaTithiIndex == 11 || kshayaTithiIndex == 26 ->
                SpecialTithiType.EKADASHI
            else -> SpecialTithiType.NONE
        }

        val isoKey = date.toString()
        val festival = remoteHolidays[isoKey]
            ?: getBuiltInFestival(date, monthIndex, isAdhik, tithiIndex, kshayaTithiIndex)

        val baseMonth = GUJARATI_MONTHS[monthIndex]
        val fullMonthName = if (isAdhik) "અધિક $baseMonth" else baseMonth

        return PanchangDay(
            date = date,
            vikramSamvat = vikramSamvat,
            gujaratiMonthIndex = monthIndex,
            gujaratiMonthName = fullMonthName,
            isAdhikMonth = isAdhik,
            tithiIndex = tithiIndex,
            pakshaName = pakshaName,
            tithiName = tithiName,
            tithiEndNote = tithiEndNote,
            tithiSpecialNote = specialNote,
            nakshatraName = nakshatraName,
            sunriseTime = formatMinutesShort(srMin),
            sunsetTime = formatMinutesShort(ssMin),
            sunriseMinutes = srMin,
            sunsetMinutes = ssMin,
            nextSunriseMinutes = nextSrMin,
            festival = festival,
            isSpecialTithi = specialType
        )
    }

    private fun getBuiltInFestival(
        date: LocalDate,
        monthIndex: Int,
        isAdhik: Boolean,
        tithiIndex: Int,
        kshayaTithiIndex: Int?
    ): String? {
        // Fixed Gregorian holidays in Gujarat
        when (date.monthValue to date.dayOfMonth) {
            1 to 14 -> return "ઉત્તરાયણ (મકરસંક્રાંતિ)"
            1 to 15 -> return "વાસી ઉત્તરાયણ"
            1 to 26 -> return "પ્રજાસત્તાક દિન"
            5 to 1 -> return "ગુજરાત સ્થાપના દિન"
            8 to 15 -> return "સ્વાતંત્ર્ય દિન"
            10 to 2 -> return "ગાંધી જયંતિ"
            10 to 31 -> return "સરદાર પટેલ જયંતિ"
            12 to 25 -> return "નાતાલ"
        }

        if (isAdhik) {
            return when {
                tithiIndex == 11 || tithiIndex == 26 || kshayaTithiIndex == 11 || kshayaTithiIndex == 26 ->
                    "અધિક અગિયારસ"
                tithiIndex == 15 -> "અધિક પૂનમ"
                tithiIndex == 30 -> "અધિક અમાસ"
                else -> null
            }
        }

        val primary = getLunarFestivalForTithi(monthIndex, tithiIndex)
        val kshayaFest = if (kshayaTithiIndex != null) {
            getLunarFestivalForTithi(monthIndex, kshayaTithiIndex)
        } else {
            null
        }

        return when {
            primary != null && kshayaFest != null && primary != kshayaFest -> "$primary / $kshayaFest"
            primary != null -> primary
            kshayaFest != null -> kshayaFest
            else -> when {
                tithiIndex == 11 || tithiIndex == 26 || kshayaTithiIndex == 11 || kshayaTithiIndex == 26 ->
                    "અગિયારસ (એકાદશી)"
                tithiIndex == 15 -> "પૂનમ"
                tithiIndex == 30 -> "અમાસ"
                else -> null
            }
        }
    }

    private fun getLunarFestivalForTithi(monthIndex: Int, tithi: Int): String? {
        // Exact Gujarati Lunar Tithis: Sud 1..15 = 1..15, Vad 1..14 = 16..29, Amavasya = 30
        return when (monthIndex to tithi) {
            // Chaitra (0)
            0 to 1 -> "ચૈત્રી નવરાત્રી પ્રારંભ / ગુડી પડવો"
            0 to 9 -> "રામ નવમી"
            0 to 15 -> "હનુમાન જયંતિ"
            // Vaishakh (1)
            1 to 3 -> "અખાત્રીજ"
            1 to 15 -> "બુદ્ધ પૂર્ણિમા"
            // Jeth (2)
            2 to 11 -> "ભીમ અગિયારસ (નિર્જળા એકાદશી)"
            2 to 15 -> "વટ સાવિત્રી પૂનમ"
            // Ashadh (3)
            3 to 2 -> "રથયાત્રા"
            3 to 11 -> "દેવશયની એકાદશી"
            3 to 15 -> "ગુરુ પૂર્ણિમા"
            // Shravan (4)
            4 to 15 -> "રક્ષાબંધન / બળેવ"
            4 to 20 -> "નાગ પંચમી"
            4 to 21 -> "રાંધણ છઠ્ઠ"
            4 to 22 -> "શીતળા સાતમ"
            4 to 23 -> "જન્માષ્ટમી"
            // Bhadarvo (5)
            5 to 4 -> "ગણેશ ચતુર્થી"
            5 to 5 -> "ઋષિ પંચમી"
            5 to 11 -> "જળઝીલણી એકાદશી"
            5 to 14 -> "અનંત ચતુર્દશી"
            5 to 30 -> "સર્વપિતૃ અમાસ (શ્રાદ્ધ સમાપ્ત)"
            // Aso (6)
            6 to 1 -> "શારદીય નવરાત્રી પ્રારંભ"
            6 to 8 -> "દુર્ગાષ્ટમી"
            6 to 10 -> "દશેરા (વિજયાદશમી)"
            6 to 15 -> "શરદ પૂર્ણિમા"
            6 to 26 -> "રમા એકાદશી"
            6 to 27 -> "વાઘ બારસ"
            6 to 28 -> "ધનતેરસ"
            6 to 29 -> "કાળી ચૌદશ"
            6 to 30 -> "દિવાળી / અમાવસ્યા"
            // Kartak (7)
            7 to 1 -> "નૂતન વર્ષ (બેસતું વર્ષ)"
            7 to 2 -> "ભાઈબીજ"
            7 to 5 -> "લાભ પાંચમ"
            7 to 7 -> "જલારામ જયંતિ"
            7 to 11 -> "પ્રબોધિની એકાદશી (દેવઊઠી અગિયારસ)"
            7 to 12 -> "તુલસી વિવાહ"
            7 to 15 -> "દેવ દિવાળી / કાર્તિકી પૂનમ"
            // Magshar (8)
            8 to 11 -> "ગીતા જયંતિ / મોક્ષદા એકાદશી"
            // Posh (9)
            9 to 15 -> "પોષી પૂનમ"
            // Maha (10)
            10 to 5 -> "વસંત પંચમી"
            10 to 29 -> "મહાશિવરાત્રી"
            // Fagan (11)
            11 to 15 -> "હોળી"
            11 to 16 -> "ધૂળેટી"
            else -> null
        }
    }

    fun getChoghadiyaForDay(panchang: PanchangDay): Pair<List<ChoghadiyaSlot>, List<ChoghadiyaSlot>> {
        val daySeq = when (panchang.date.dayOfWeek) {
            DayOfWeek.SUNDAY -> listOf("ઉદ્વેગ", "ચલ", "લાભ", "અમૃત", "કાળ", "શુભ", "રોગ", "ઉદ્વેગ")
            DayOfWeek.MONDAY -> listOf("અમૃત", "કાળ", "શુભ", "રોગ", "ઉદ્વેગ", "ચલ", "લાભ", "અમૃત")
            DayOfWeek.TUESDAY -> listOf("રોગ", "ઉદ્વેગ", "ચલ", "લાભ", "અમૃત", "કાળ", "શુભ", "રોગ")
            DayOfWeek.WEDNESDAY -> listOf("લાભ", "અમૃત", "કાળ", "શુભ", "રોગ", "ઉદ્વેગ", "ચલ", "લાભ")
            DayOfWeek.THURSDAY -> listOf("શુભ", "રોગ", "ઉદ્વેગ", "ચલ", "લાભ", "અમૃત", "કાળ", "શુભ")
            DayOfWeek.FRIDAY -> listOf("ચલ", "લાભ", "અમૃત", "કાળ", "શુભ", "રોગ", "ઉદ્વેગ", "ચલ")
            DayOfWeek.SATURDAY -> listOf("કાળ", "શુભ", "રોગ", "ઉદ્વેગ", "ચલ", "લાભ", "અમૃત", "કાળ")
        }

        val nightSeq = when (panchang.date.dayOfWeek) {
            DayOfWeek.SUNDAY -> listOf("શુભ", "અમૃત", "ચલ", "રોગ", "કાળ", "લાભ", "ઉદ્વેગ", "શુભ")
            DayOfWeek.MONDAY -> listOf("ચલ", "રોગ", "કાળ", "લાભ", "ઉદ્વેગ", "શુભ", "અમૃત", "ચલ")
            DayOfWeek.TUESDAY -> listOf("કાળ", "લાભ", "ઉદ્વેગ", "શુભ", "અમૃત", "ચલ", "રોગ", "કાળ")
            DayOfWeek.WEDNESDAY -> listOf("ઉદ્વેગ", "શુભ", "અમૃત", "ચલ", "રોગ", "કાળ", "લાભ", "ઉદ્વેગ")
            DayOfWeek.THURSDAY -> listOf("અમૃત", "ચલ", "રોગ", "કાળ", "લાભ", "ઉદ્વેગ", "શુભ", "અમૃત")
            DayOfWeek.FRIDAY -> listOf("રોગ", "કાળ", "લાભ", "ઉદ્વેગ", "શુભ", "અમૃત", "ચલ", "રોગ")
            DayOfWeek.SATURDAY -> listOf("લાભ", "ઉદ્વેગ", "શુભ", "અમૃત", "ચલ", "રોગ", "કાળ", "લાભ")
        }

        val isToday = panchang.date == LocalDate.now()
        val now = LocalTime.now()
        val nowMin = now.hour * 60 + now.minute

        val dayLen = (panchang.sunsetMinutes - panchang.sunriseMinutes) / 8.0
        val daySlots = daySeq.mapIndexed { idx, name ->
            val start = (panchang.sunriseMinutes + idx * dayLen).roundToInt()
            val end = (panchang.sunriseMinutes + (idx + 1) * dayLen).roundToInt()
            val active = isToday && nowMin in start until end
            buildSlot(name, start, end, active)
        }

        val nightLen = (panchang.nextSunriseMinutes - panchang.sunsetMinutes) / 8.0
        val nightSlots = nightSeq.mapIndexed { idx, name ->
            val start = (panchang.sunsetMinutes + idx * nightLen).roundToInt()
            val end = (panchang.sunsetMinutes + (idx + 1) * nightLen).roundToInt()
            val effectiveNow = if (nowMin < panchang.sunriseMinutes) nowMin + 1440 else nowMin
            val active = isToday && effectiveNow in start until end
            buildSlot(name, start, end, active)
        }

        return daySlots to nightSlots
    }

    private fun buildSlot(name: String, startMin: Int, endMin: Int, isCurrent: Boolean): ChoghadiyaSlot {
        val (nature, quality) = when (name) {
            "અમૃત" -> "અતિ શુભ" to ChoghadiyaQuality.SHUBH
            "શુભ" -> "શુભ" to ChoghadiyaQuality.SHUBH
            "લાભ" -> "લાભદાયી (શુભ)" to ChoghadiyaQuality.SHUBH
            "ચલ" -> "સામાન્ય" to ChoghadiyaQuality.NEUTRAL
            "રોગ" -> "અશુભ" to ChoghadiyaQuality.ASHUBH
            "કાળ" -> "અશુભ" to ChoghadiyaQuality.ASHUBH
            else -> "અશુભ" to ChoghadiyaQuality.ASHUBH
        }
        val range = "${formatMinutesShort(startMin)} થી ${formatMinutesShort(endMin)}"
        return ChoghadiyaSlot(name, nature, quality, range, isCurrent)
    }
}
