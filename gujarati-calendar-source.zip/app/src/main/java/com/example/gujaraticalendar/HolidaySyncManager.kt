package com.example.gujaraticalendar

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class SyncResult(
    val success: Boolean,
    val holidays: Map<String, String>,
    val message: String
)

object HolidaySyncManager {

    private const val BASE_REMOTE_JSON_URL =
        "https://raw.githubusercontent.com/2mindhunter1/gujarati-calendar/main/holidays.json"

    private const val PREFS_NAME = "guj_calendar_prefs"
    private const val KEY_CACHED_JSON = "cached_holidays_json"

    fun getCachedHolidays(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_CACHED_JSON, null) ?: return emptyMap()
        return parseHolidaysJson(raw)
    }

    suspend fun syncFromGitHub(context: Context): SyncResult {
        return withContext(Dispatchers.IO) {
            try {
                // Cache-busting timestamp so GitHub CDN gives instant real-time updates
                val liveUrl = "$BASE_REMOTE_JSON_URL?t=${System.currentTimeMillis()}"
                val url = URL(liveUrl)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    useCaches = false
                    setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate")
                    setRequestProperty("Pragma", "no-cache")
                    requestMethod = "GET"
                }

                val code = conn.responseCode
                if (code == 200) {
                    val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                    val parsed = parseHolidaysJson(responseText)
                    if (parsed.isNotEmpty()) {
                        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                            .edit()
                            .putString(KEY_CACHED_JSON, responseText)
                            .apply()
                        val countGuj = PanchangEngine.toGujaratiDigits(parsed.size)
                        return@withContext SyncResult(
                            success = true,
                            holidays = parsed,
                            message = "રીઅલ-ટાઈમ અપડેટ પૂર્ણ! ($countGuj તહેવારો સિંક થયા)"
                        )
                    } else {
                        return@withContext SyncResult(
                            success = false,
                            holidays = getCachedHolidays(context),
                            message = "holidays.json ફાઈલ ખાલી અથવા ખોટા ફોર્મેટમાં છે"
                        )
                    }
                } else {
                    return@withContext SyncResult(
                        success = false,
                        holidays = getCachedHolidays(context),
                        message = "GitHub પર holidays.json મળી નથી (Code: $code)"
                    )
                }
            } catch (_: Exception) {
                return@withContext SyncResult(
                    success = false,
                    holidays = getCachedHolidays(context),
                    message = "ઓનલાઈન કનેક્શન નથી (ઓફલાઈન પંચાંગ ચાલુ છે)"
                )
            }
        }
    }

    private fun parseHolidaysJson(jsonText: String): Map<String, String> {
        return try {
            val root = JSONObject(jsonText)
            val arr = root.optJSONArray("holidays") ?: return emptyMap()
            val map = mutableMapOf<String, String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val date = obj.optString("date", "").trim()
                val title = obj.optString("title", "").trim()
                if (date.isNotEmpty() && title.isNotEmpty()) {
                    map[date] = title
                }
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
