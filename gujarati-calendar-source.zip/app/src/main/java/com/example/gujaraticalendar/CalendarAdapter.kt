package com.example.gujaraticalendar

import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.time.DayOfWeek
import java.time.LocalDate

class CalendarAdapter(
    private var cells: List<CalendarCell>,
    private var selectedDate: LocalDate,
    private val onDateSelected: (LocalDate) -> Unit
) : RecyclerView.Adapter<CalendarAdapter.DayViewHolder>() {

    class DayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cellRoot: LinearLayout = view.findViewById(R.id.cellRoot)
        val tvEngDate: TextView = view.findViewById(R.id.tvEngDate)
        val tvGujTithi: TextView = view.findViewById(R.id.tvGujTithi)
        val tvCellTag: TextView = view.findViewById(R.id.tvCellTag)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_calendar_day, parent, false)
        return DayViewHolder(view)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        val cell = cells[position]
        val date = cell.date
        val panchang = cell.panchang

        if (date == null || panchang == null) {
            holder.tvEngDate.text = ""
            holder.tvGujTithi.text = ""
            holder.tvCellTag.text = ""
            holder.tvCellTag.visibility = View.INVISIBLE
            holder.cellRoot.setBackgroundColor(Color.TRANSPARENT)
            holder.cellRoot.setOnClickListener(null)
            return
        }

        val today = LocalDate.now()
        val isToday = date == today
        val isSelected = date == selectedDate
        val isSunday = date.dayOfWeek == DayOfWeek.SUNDAY

        holder.tvEngDate.text = date.dayOfMonth.toString()

        val tithiLabel = PanchangEngine.getCompactGridTithi(
            panchang.tithiIndex,
            panchang.kshayaTithiIndex
        )
        holder.tvGujTithi.text = tithiLabel
        holder.tvGujTithi.setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            if (panchang.kshayaTithiIndex != null) 8.5f else 10f
        )

        when {
            isSelected -> holder.cellRoot.setBackgroundResource(R.drawable.bg_day_selected)
            isToday -> holder.cellRoot.setBackgroundResource(R.drawable.bg_day_today)
            else -> holder.cellRoot.setBackgroundResource(R.drawable.bg_day_normal)
        }

        val hasMajorFestival = panchang.festival != null &&
            panchang.festival != "અગિયારસ (એકાદશી)" &&
            panchang.festival != "પૂનમ" &&
            panchang.festival != "અમાસ"

        holder.tvEngDate.setTextColor(
            when {
                isSelected -> Color.WHITE
                isSunday || hasMajorFestival -> Color.parseColor("#C62828")
                else -> Color.parseColor("#1C1B1F")
            }
        )

        holder.tvGujTithi.setTextColor(
            when {
                isSelected -> Color.parseColor("#FFF8E1")
                panchang.kshayaTithiIndex != null -> Color.parseColor("#B71C1C")
                panchang.isVridhiTithi -> Color.parseColor("#0D47A1")
                panchang.isSpecialTithi == SpecialTithiType.POONAM -> Color.parseColor("#E65100")
                panchang.isSpecialTithi == SpecialTithiType.AMAS -> Color.parseColor("#283593")
                panchang.isSpecialTithi == SpecialTithiType.EKADASHI -> Color.parseColor("#2E7D32")
                else -> Color.parseColor("#4E342E")
            }
        )

        when {
            panchang.kshayaTithiIndex != null -> {
                holder.tvCellTag.visibility = View.VISIBLE
                holder.tvCellTag.text = "ધોકો"
                holder.tvCellTag.setTextColor(
                    if (isSelected) Color.parseColor("#FFD54F") else Color.parseColor("#D50000")
                )
            }
            panchang.isVridhiTithi -> {
                holder.tvCellTag.visibility = View.VISIBLE
                val numGuj = PanchangEngine.toGujaratiDigits(
                    PanchangEngine.getTithiNumberInPaksha(panchang.tithiIndex)
                )
                holder.tvCellTag.text = "બે $numGuj"
                holder.tvCellTag.setTextColor(
                    if (isSelected) Color.parseColor("#FFD54F") else Color.parseColor("#1565C0")
                )
            }
            panchang.isSpecialTithi == SpecialTithiType.EKADASHI -> {
                holder.tvCellTag.visibility = View.VISIBLE
                holder.tvCellTag.text = "અગિયારસ"
                holder.tvCellTag.setTextColor(
                    if (isSelected) Color.WHITE else Color.parseColor("#2E7D32")
                )
            }
            panchang.festival != null -> {
                holder.tvCellTag.visibility = View.VISIBLE
                holder.tvCellTag.text = "●"
                holder.tvCellTag.setTextColor(
                    if (isSelected) Color.WHITE else Color.parseColor("#D84315")
                )
            }
            else -> {
                holder.tvCellTag.visibility = View.INVISIBLE
            }
        }

        holder.cellRoot.setOnClickListener {
            onDateSelected(date)
        }
    }

    override fun getItemCount(): Int = cells.size

    fun updateData(newCells: List<CalendarCell>, newSelected: LocalDate) {
        cells = newCells
        selectedDate = newSelected
        notifyDataSetChanged()
    }
}
