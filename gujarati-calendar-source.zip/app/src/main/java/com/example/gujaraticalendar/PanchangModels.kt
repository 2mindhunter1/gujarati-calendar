package com.example.gujaraticalendar

import java.time.LocalDate

data class PanchangDay(
    val date: LocalDate,
    val vikramSamvat: Int,
    val gujaratiMonthIndex: Int, // 0=ચૈત્ર .. 7=કારતક .. 11=ફાગણ
    val gujaratiMonthName: String,
    val isAdhikMonth: Boolean,
    val tithiIndex: Int, // 1..30 (1..15 Sud, 16..30 Vad)
    val pakshaName: String, // સુદ / વદ
    val tithiName: String, // એકમ .. પૂનમ / અમાસ
    val tithiEndNote: String,
    val tithiSpecialNote: String?,
    val nakshatraName: String,
    val sunriseTime: String,
    val sunsetTime: String,
    val sunriseMinutes: Int,
    val sunsetMinutes: Int,
    val nextSunriseMinutes: Int,
    val festival: String? = null,
    val isSpecialTithi: SpecialTithiType = SpecialTithiType.NONE
)

enum class SpecialTithiType {
    NONE, POONAM, AMAS, EKADASHI
}

data class CalendarCell(
    val date: LocalDate?,
    val panchang: PanchangDay?
)

data class ChoghadiyaSlot(
    val name: String,
    val nature: String,
    val quality: ChoghadiyaQuality,
    val timeRange: String,
    val isCurrent: Boolean
)

enum class ChoghadiyaQuality {
    SHUBH, NEUTRAL, ASHUBH
}
